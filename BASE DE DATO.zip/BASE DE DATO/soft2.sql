-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 22-09-2018 a las 08:04:22
-- Versión del servidor: 10.1.35-MariaDB
-- Versión de PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `soft2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(8, '2014_10_12_000000_create_users_table', 1),
(9, '2014_10_12_100000_create_password_resets_table', 1),
(10, '2018_09_22_020133_entrust_setup_tables', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'ADMINISTRADOR', 'admini', NULL, NULL),
(2, 'revisor', 'REVISOR', 'revisa anuncio', NULL, NULL),
(3, 'cliente', 'CLIENTE', 'cliente', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `role_user`
--

CREATE TABLE `role_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 1),
(8, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'skin-blue',
  `foto` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `color`, `foto`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@admin.com', '$2y$10$y027Jaezcfbi.jYqZ38GU.LwqnNBu.4oKcdH6YXJP.xGmo8Bmcu3i', '1', 'skin-blue ', NULL, 'Pmi0vwRHNJo4N7dtYTXGYIitCCgmNlAaF0JVdAKzLENMVMLZqRi6TgrPa6k6', '2017-05-31 03:50:39', '2018-09-22 06:32:02'),
(2, 'hola', 'hola@hola.com', '$2y$10$r3FKySxHgEFlo.Xc4O9OIuWrWiKXbUCGCbTWs7S1X5O6R4wrVThfS', '3', NULL, NULL, 'dRMADpFKXy2GCy8aQnqpxb6lZ98Q11lT7B1vJYbv4Ndr0yEvbbp1DvsbansC', '2018-09-22 06:33:57', '2018-09-22 06:33:57'),
(3, 'asdad', 'aadasd@dfgdfg.com', '$2y$10$3VhS0hK7gQ9USxBeZwdnVud0.bKn9Y8ovN9b4uTDKm3Ab0v5nn00G', '3', 'skin-blue ', NULL, 'IX5a4mM5svlt1ygZmuJnSFKXjiwclPi1EVcnJf5h5NnCxYKkKOAcbNMy5MQb', '2018-09-22 08:12:06', '2018-09-22 08:12:23'),
(4, 'hola', 'a@a.com', '$2y$10$YkN/vc3XqwD8av./QwZ4xu7YhOCCkFdVJCAOGX0Uxc/ktxna0lI/G', '3', 'skin-blue', NULL, 'hddLsMXz8HuIZlAhXcXeGpFP0HLt7gq6xwizM0LUiXTrpaIn2CHD9ZLOaqPD', '2018-09-22 08:13:30', '2018-09-22 08:13:33'),
(5, 'dfsdf', '1@1.com', '$2y$10$WLIsl0GeWEd4dp1lA2pXb.iS69Iy0mymPC1Xmv.kd1QGGFAGTGYA.', '3', NULL, NULL, 'MtyebwXomJyOTQCOTXVtiTje0olku4Nl6J07sqdLtVrBXT02fcayjMlrAivU', '2018-09-22 08:18:35', '2018-09-22 08:18:35'),
(6, 'ghg', '2@2.com', '$2y$10$Ll8EG1AFAKAqSaV9PMN4u.nG9DA5ID7ivyR62heatZnHnWajBMqku', '3', NULL, NULL, NULL, '2018-09-22 08:21:25', '2018-09-22 08:21:25'),
(7, 'dfsdf', '33@gmail.com', '$2y$10$8M6zTCPhTd9mizzm5DR1oOGozUafGrA0J21t.5.GuFYxo9jhtIgIe', '3', NULL, 'estacion1.png', '6siiFfYWNvACz5pAgkCOJ9MeNMotEfDyRHOgav7cQEvRURm3dguuVDzPhM5N', '2018-09-22 08:25:20', '2018-09-22 08:32:13'),
(8, 'revisor 1', 'revi@revi.cl', '$2y$10$o74WiuCRZGpSyLuLdB7sYu4GBNQHVfVLBFkZJs.1oFYt5HInpD3VS', NULL, NULL, NULL, NULL, '2018-09-22 08:34:36', '2018-09-22 08:34:36'),
(9, 'hola', 'mj.leontorres@gmail.com', '$2y$10$ZtfVAQAY3qbYRGq0k20iu.YIplIqZzpeXF1d3fuNjL2QcaNF7sXbK', '3', 'skin-blue', NULL, 'wb8f11P5JFLNM43FZjUN2xKGWycnG2HzDISbCcFdWSRtYJlrv1hMbAT7easC', '2018-09-22 08:41:27', '2018-09-22 08:41:27'),
(10, 'c xcv', '3@3.com', '$2y$10$jGYbKUtnpSE1zKrvWVf/OujEU.E/Xq4DPzk0oiCwKlUIbsUetQxZy', '3', NULL, NULL, '8tgXjRDvSCWFUTqVrORfFzkjdjaAuDpHI39Can0ZbepI4arxHuIAdUEPyMKq', '2018-09-22 08:43:17', '2018-09-22 08:43:17'),
(11, 'cccv', 'admin@example.com', '$2y$10$J1GgVQXO8o5LNIx/cRMI7OBd.yz2mvEObsfA5n0hIhuuD9hg1gUtO', '3', 'skin-red', 'user2-160x160.png', NULL, '2018-09-22 08:45:26', '2018-09-22 08:56:27');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indices de la tabla `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indices de la tabla `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
